function exf(s, n) {
  for (let i = 0; i < n; i++) {
    console.log(s);
  }
}

// Test calls
exf("echo", 5);
exf("JS from server", 10);

// To run this file, use the command:
// node echo.js